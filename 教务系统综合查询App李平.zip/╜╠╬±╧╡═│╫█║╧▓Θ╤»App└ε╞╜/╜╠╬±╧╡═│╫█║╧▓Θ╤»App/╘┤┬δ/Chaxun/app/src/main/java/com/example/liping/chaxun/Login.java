package com.example.liping.chaxun;

/**
 * Created by liping on 2016/12/18.
 */


    import java.io.IOException;
    import java.io.UnsupportedEncodingException;
    import java.util.ArrayList;
    import java.util.List;

    import org.apache.http.HttpEntity;
    import org.apache.http.HttpResponse;
    import org.apache.http.client.HttpClient;
    import org.apache.http.client.entity.UrlEncodedFormEntity;
    import org.apache.http.client.methods.CloseableHttpResponse;
    import org.apache.http.client.methods.HttpGet;
    import org.apache.http.client.methods.HttpPost;
    import org.apache.http.impl.client.CloseableHttpClient;
    import org.apache.http.impl.client.DefaultHttpClient;
    import org.apache.http.message.BasicNameValuePair;
    import org.apache.http.util.EntityUtils;
    import org.jsoup.Jsoup;
    import org.jsoup.nodes.Document;
    import org.jsoup.nodes.Element;
    import org.jsoup.select.Elements;

public class Login {


        public static void main(String[] args) {
            //System.out.println("我在这1");
            doit();
        }

        public static void doit(){

            final CloseableHttpClient client=new DefaultHttpClient();
            new Thread(){
                @Override
                public void run() {
                    try {
                        getPost();

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                public void getPost() throws IOException {
                    HttpPost post=new HttpPost("http://bkjw.guet.edu.cn/student/public/login.asp");
                    List<BasicNameValuePair> parameters=new ArrayList<>();
                    parameters.add(new BasicNameValuePair("username","1400710324"));
                    parameters.add(new BasicNameValuePair("passwd","142515"));
                    parameters.add(new BasicNameValuePair("login","登陆"));
                    post.setEntity(new UrlEncodedFormEntity(parameters,"GBK"));
                    CloseableHttpResponse response=client.execute(post);
                    System.out.println(response.getStatusLine().getStatusCode());
                    response.close();

                    HttpGet get=new HttpGet("http://bkjw.guet.edu.cn/student/Score.asp?lwBtnquery=查询&lwPageSize=100");
                    CloseableHttpResponse response2= client.execute(get);
                    HttpEntity entity2= response2.getEntity();
                    String data= EntityUtils.toString(entity2, "GBK");
                    System.out.println(filterHtml(data));

                }
//            public String getData() throws IOException {
//                HttpGet get=new HttpGet("http://bkjw.guet.edu.cn/student/Score.asp?lwBtnquery=查询&lwPageSize=100");
//                HttpResponse response= client.execute(get);
//                HttpEntity entity= response.getEntity();
//                String data= EntityUtils.toString(entity, "GBK");
//
//                return data;
//            }
            }.start();
        }
        private static String filterHtml(String source) {
            if (null == source) {
                return "";
            }

            StringBuffer sff = new StringBuffer();
            String score[];
            int i = 0;
            String html = source;
            Document doc = Jsoup.parse(html);   //把HTML代码加载到doc中
            Elements links_class = doc.select("td"); // 这是课程名，因为课程名的HTML标签事<td width=23% align=left>，然后我发现<span style="font-family: Arial, Helvetica, sans-serif;">width=23%是这个标签特有的，所以我就把它给提出来了</span>

            for (Element link : links_class) {
                if(i++==5){
                    sff.append(link.text()).append("\n");
                    i=0;
                }
                else{
                    sff.append(link.text()).append(" : ");

                }

            }
            html = sff.toString();
            return html;
        }
    }

