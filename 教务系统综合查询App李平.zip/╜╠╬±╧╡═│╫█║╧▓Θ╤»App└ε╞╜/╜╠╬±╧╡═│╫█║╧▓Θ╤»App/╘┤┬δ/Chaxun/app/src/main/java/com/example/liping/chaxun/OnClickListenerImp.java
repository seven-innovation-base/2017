package com.example.liping.chaxun;

import android.app.ProgressDialog;
import android.content.Context;

/**
 * Created by liping on 2017/2/24.
 */
public class OnClickListenerImp{

    public static void getProgress(Context context) {
        final ProgressDialog proDia = new ProgressDialog(context);
        proDia.setTitle("数据请求中");
        proDia.setMessage("请耐心等待");
        proDia.onStart();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }finally {
                    proDia.dismiss();
                }

            }
        }).start();
        proDia.show();
    }

}

