package com.example.liping.chaxun;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.io.Closeable;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by liping on 2016/12/18.
 */
public class LoginRequest {

    static  int i;
    /**
     * 登陆选课系统
     * @param username
     * @param password
     * @param client
     * @return
     */
    public  static int  LinkJW(final String username, final String password, final HttpClient client) {

        try {
            HttpPost post = new HttpPost("http://bkjw.guet.edu.cn/student/public/login.asp");
            List<BasicNameValuePair> parameters = new ArrayList<>();
            parameters.add(new BasicNameValuePair("username", username));
            parameters.add(new BasicNameValuePair("passwd", password));
            parameters.add(new BasicNameValuePair("login", "登陆"));
            System.out.println("账号"+username+"密码"+password);
            post.setEntity(new UrlEncodedFormEntity(parameters, "GBK"));
            HttpResponse response= client.execute(post);
//            ((Closeable) response).close();
            i= response.getStatusLine().getStatusCode();


                System.out.println("我咋还在这里"+i);
        } catch (UnsupportedEncodingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (ClientProtocolException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return i;
    }
}
