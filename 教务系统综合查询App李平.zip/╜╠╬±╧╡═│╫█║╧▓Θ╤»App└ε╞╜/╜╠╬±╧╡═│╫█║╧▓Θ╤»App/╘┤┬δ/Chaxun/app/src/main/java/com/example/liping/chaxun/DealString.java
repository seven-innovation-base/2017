package com.example.liping.chaxun;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liping on 2016/12/18.
 */
public class DealString {

    /**
     * 输入html文档 ，要进行切的标签 还有事哪一个查询项  返回一个list集合
     * @param source
     * @param statu
     * @return
     */
    public  static List<String> filterHtml(String source,String statu) {
        List list=new ArrayList<String>();

        if (null == source) {
            return null;
        }

        String html = source;
        Document doc = Jsoup.parse(html);   //把HTML代码加载到doc中
        Elements links_class = doc.select(statu);
        for(Element element:links_class){

            list.add(element.text());

        }

        return list;
    }




}
